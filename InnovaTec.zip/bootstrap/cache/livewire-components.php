<?php return array (
  'proyectos' => 'App\\Http\\Livewire\\Proyectos',
);