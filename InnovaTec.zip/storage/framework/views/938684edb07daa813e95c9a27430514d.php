<div>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center justify-center">
            <img src="<?php echo e(asset('/build/assets/img/logo.png')); ?>" class="h-16" alt="Logo Tec nacional">

        </div>
     <?php $__env->endSlot(); ?>

    <div class="flex flex-col">
        <div class="overflow-x-auto p-5">
            <div class="inline-block min-w-full py-2 sm:px-6 lg:px-8">
                <h2 class="font-semibold text-3xl mb-5 text-gray-800 leading-tight">
                    <?php echo e(__('Proyectos Innovatecmn')); ?>

                </h2>
                <div class="overflow-hidden shadow-xl rounded-lg">
                    <div class="pt-5 px-5 flex gap-10 bg-slate-50">

                        <div class="flex items-center">
                            <span>Mostrar</span>
                            <select wire:model="cant"
                                class="mx-2 border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm">
                                <option value="10">10</option>
                                <option value="25">25</option>
                                <option value="50">50</option>
                                <option value="100">100</option>
                            </select>
                            <span>entradas</span>
                        </div>

                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['wire:model' => 'search','placeholder' => 'Buscar por nombre o escuela','class' => 'w-full p-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'search','placeholder' => 'Buscar por nombre o escuela','class' => 'w-full p-2']); ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Buscar <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                    </div>

                    <?php if($proyectos->count()): ?>
                        <table class="min-w-full text-left text-sm font-light">
                            <thead class="border-b font-medium bg-slate-50">
                                <tr>
                                    <th scope="col" class="px-6 py-4">Nombre</th>
                                    <th scope="col" class="px-6 py-4">Descripción</th>
                                    <th scope="col" class="px-6 py-4">Institución</th>
                                    <th scope="col" class="px-6 py-4">Calificación</th>
                                    <th scope="col" class="px-6 py-4">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="border-b bg-white">
                                        <td class="whitespace-nowrap px-10 py-4 text-xl"><?php echo e($item->NombreCorto); ?></td>
                                        <td class="px-10 py-4 capitalize-first max-w-xs">
                                            <?php echo e($item->NombreDescriptivo); ?>

                                        </td>
                                        <td class="whitespace-nowrap px-10 py-4"><?php echo e($item->Nombre); ?></td>
                                        <td class="whitespace-nowrap px-10 py-4"><?php echo e($item->Calificacion); ?></td>
                                        <td class="px-10 py-4">
                                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['wire:click' => 'mostrar(\''.e($item->Id).'\')','type' => 'button']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'mostrar(\''.e($item->Id).'\')','type' => 'button']); ?>Ver más
                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="p-5">No existe ningún registro coincidente.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php if($modal): ?>
            <?php echo $__env->make('livewire.mostrar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <?php if($proyectos->hasPages()): ?>
            <div class="p-5">
                <?php echo e($proyectos->links()); ?>

            </div>
        <?php endif; ?>
    </div>


</div>
<?php /**PATH C:\xampp\htdocs\Laravel\InnovaTec\resources\views/livewire/proyectos.blade.php ENDPATH**/ ?>