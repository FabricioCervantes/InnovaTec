<div>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dialog-modal','data' => ['maxWidth' => '2xl','wire:model' => 'modal','class' => 'flex items-center']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dialog-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['maxWidth' => '2xl','wire:model' => 'modal','class' => 'flex items-center']); ?>
         <?php $__env->slot('title', null, []); ?> Información del proyecto <?php $__env->endSlot(); ?>
         <?php $__env->slot('content', null, []); ?> 
            <div class="flex gap-10 justify-between">
                <div>
                    <div class="mb-4">
                        <h1 class="text-xl">Nombre del proyecto </h1>
                        <p class="text-lg whitespace-normal text-justify capitalize-first"><?php echo e(strip_tags($NombreCorto)); ?>

                        </p>
                    </div>
                    <div class="mb-4">
                        <h1 class="text-xl">Nombre de la escuela </h1>
                        <p class="text-lg whitespace-normal text-justify capitalize-first"><?php echo e(strip_tags($Nombre)); ?></p>
                    </div>
                    
                    <div class="mb-4 w-96">
                        <h1 class="text-xl">Observaciones</h1>
                        <p class="text-sm whitespace-normal text-justify capitalize-first"><?php echo e(strip_tags($comentario)); ?>

                        </p>
                    </div>
                </div>
                <div>
                    <div class="mb-4">
                        <h1 class="text-lg">Calificación </h1>
                        <p class="text-xl whitespace-normal text-justify capitalize-first">

                            <?php echo e(strip_tags($Calificacion)); ?></p>
                    </div>
                    <div class="mb-4">
                        <h1 class="text-xl">Integrantes: </h1>
                        <?php $__currentLoopData = $Usuario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p class="text-xs whitespace-normal text-justify capitalize-first"><?php echo e($item); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <div class="mb-4">
                <h1 class="text-2xl">Descripción de la problemática </h1>
                <div class="text-sm whitespace-normal text-justify capitalize-first ">
                    <?php echo e(strip_tags($DescripciónProblematica)); ?></div>
            </div>
            <div class="mb-4">
                <h1 class="text-2xl">Objetivo </h1>
                <p class="text-sm whitespace-normal text-justify capitalize-first"><?php echo e(strip_tags($Objetivo)); ?></p>
            </div>
            <div class="mb-4 test">
                <h1 class="text-2xl">Resultados a alcanzar </h1>
                <p class="text-sm whitespace-normal text-justify capitalize-first"><?php echo e(strip_tags($ResultadosAlcanzar)); ?>

                </p>
            </div>
         <?php $__env->endSlot(); ?>
         <?php $__env->slot('footer', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.danger-button','data' => ['wire:click' => 'cerrarModal']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'cerrarModal']); ?>Cerrar <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

</div>
<script></script>
<?php /**PATH C:\xampp\htdocs\Laravel\InnovaTec\resources\views/livewire/mostrar.blade.php ENDPATH**/ ?>